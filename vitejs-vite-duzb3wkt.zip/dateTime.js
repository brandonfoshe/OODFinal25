// this function used to display time in a digestiable manner as part of the display method
// method from https://stackoverflow.com/questions/141348/how-to-parse-a-time-into-a-date-object-from-user-input-in-javascript

export function parseTime( t ) {
  let temp = String(t);

  if (temp.length <3 || temp.length>4){
    return "Invalid Time Format, Use:0001-2359"
  }

  if (temp.length === 3){
   temp ="0"+temp;
  }

  let hours = parseInt(temp.slice(0, 2));
  let minutes = parseInt(temp.slice(2, 4));

  if(hours>23 || minutes> 59){
    return 'Invalid Time, must be a number between 0001 and 2359';
  }
  const am = hours>=12 ? 'PM':'AM';
  let hours2 = hours%12;
  if (hours2 === 0) hours2=12;

  const minutes2 =minutes.toString().padStart(2,'0');
  return hours2+':'+minutes2+' '+am;
}

export function parseDuration( t ) {
  const temp = String(t);

  if (t !== 0) return '0 Minutes';

  let duration = ''

  let hours = parseInt(temp.slice(0,2));
  let minutes = parseInt(temp.slice(2,4));
  
  if(hours>23 || minutes> 59){
    return 'Invalid Time, must be a number between 0001 and 2399';
  }
  if (hours2 === 0) hours2=12;

  const minutes2 =minutes.toString().padStart(2,'0');
  return hours2+':'+minutes2+' ';
}