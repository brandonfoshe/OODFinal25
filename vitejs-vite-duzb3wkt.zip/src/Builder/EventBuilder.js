// Authored by Brandon and Hayden
// The purpose of the Builder is to be called in the form Stage of Creation, on the submit factory calls a constant builder which then return a Work or Personal Event with the Proper Specifications


import {WorkEvent} from "../Event/WorkEvent"
import {PersonalEvent} from "../Event/PersonalEvent"

export class EventBuilder {

    //HEADER:
    //Builder with functions to build each type of event
    constructor() {
        this.time = undefined;
        this.duration = undefined;
        this.title = undefined;
        this.description = undefined;
        this.location = undefined;
        this.company = undefined;
        this.day = undefined;
      }

        //Setters for each element of the calendar
  setTime(time){
      this.time = time;
      console.log(this)
      return this
  }

  setDuration(duration){
      this.duration = duration;
      return this
  }

  setTitle(title){
      this.title = title;
      return this
  }

  setDescription( description){
      this.description = description;
      return this
  }

  setLocation( location){
      this.location = location;
      return this
  }

  setCompany( company){
     this.company = company;
     return this
  }

  setDay( day){
      this.day = day;
      console.log(this)
      return this
  }
 //Build a work event,
  buildWorkEvent(){
      const newWork = new WorkEvent(
        this.time,
        this.duration,
        this.title,
        this.description,
        this.location,
        this.day);
      return newWork
  }
//Build a personal event,
   buildPersonalEvent(){
       const newPersonal = new PersonalEvent(
        this.time,
        this.duration,
        this.title,
        this.description,
        this.location,
        this.day);
      return newPersonal
  }
}