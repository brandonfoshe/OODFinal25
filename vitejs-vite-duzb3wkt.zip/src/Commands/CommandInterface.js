//https://www.geeksforgeeks.org/system-design/command-method-javascript-design-patterns/
// JavaScript is slighty diffrent in it's methods to achieve what java does so i needed help here

export class CommandInterface{
  constructor(){
    if(new.target === CommandInterface){
        throw new error(""); 
    }
  }
  async execute(){
    throw new error("");
  }
}