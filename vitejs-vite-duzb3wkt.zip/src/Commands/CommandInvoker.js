// Authored by : Hayden Jones
// A director of Commands, Encapsulates a Command, Storing one to be executed


export class CommandInvoker {
  constructor(){

  }
  setCommand(command){
    this.command = command;
  }

  async executeCommand(){
    const result = await this.command.execute();
    return result;
  }
}