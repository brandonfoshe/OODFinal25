
export class CommandInvoker {
  constructor(){

  }
  setCommand(command){
    this.command = command;
  }

  async executeCommand(){
    const result = await this.command.execute();
    return result;
  }
}