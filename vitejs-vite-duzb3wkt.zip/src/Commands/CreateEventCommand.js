import {CommandInterface} from './CommandInterface';
import { db } from '../../firebase.js';
import {collection, addDoc,doc} from 'firebase/firestore'
import {Event} from '../Event/Event.js';

export class CreateEventCommand extends CommandInterface{
  constructor(eventObj){
    super();
    this.event= eventObj;
  }

  async execute(){
    try{ 
      const newDoc = await addDoc(collection(db,'events'),this.event.toFirestore())
    } catch (error){
      throw error;
    }
  }
}