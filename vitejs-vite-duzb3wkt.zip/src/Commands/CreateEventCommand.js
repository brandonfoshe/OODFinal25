// Authored by : Hayden Jones
// This Command Imports nessacary components to Create an Event Via FireBase, This Doesnt Really Create Commands as much as it Communicates created Commands with Firebase , as such the db import and the lack of builder and factory usage here 

import {CommandInterface} from './CommandInterface';
import { db } from '../../firebase.js';
import {collection, addDoc,doc} from 'firebase/firestore'
import {Event} from '../Event/Event.js';

export class CreateEventCommand extends CommandInterface{
  constructor(eventObj){
    super();
    this.event= eventObj;
  }

  async execute(){
    try{ 
      const newDoc = await addDoc(collection(db,'events'),this.event.toFirestore())
    } catch (error){
      throw error;
    }
  }
}