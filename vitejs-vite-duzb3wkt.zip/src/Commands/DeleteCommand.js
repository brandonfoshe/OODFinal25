import {doc,deleteDoc} from 'firebase/firestore';
import {CommandInterface} from './CommandInterface'
import { db } from '/firebase.js';

export class DeleteCommand extends CommandInterface{
  constructor(eventObj){
    super();
    this.event= eventObj;
  }

  async execute(){
    try{
      const ID = this.event.id;
      const Doc = doc(db,'events',ID);
      await deleteDoc(Doc)
      } catch (error){
        throw error;
      }
  }
}