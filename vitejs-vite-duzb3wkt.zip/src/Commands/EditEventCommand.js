import { setDoc,doc,getDoc } from 'firebase/firestore';
import {CommandInterface} from './CommandInterface'
import { db } from '/firebase.js';

export class EditEventCommand extends CommandInterface{
  constructor(eventObj){
    super();
    this.event= eventObj;
  }

  async execute(){
    try{
      const docID = this.event.id;
      const updateFrom = doc(db,"events",docID);
      const updateTo = {...this.event}
      const UpdateFromData = await getDoc(updateFrom)
      const dayTemp = UpdateFromData.data().day;
      console.log(updateFrom)
      console.log(updateTo)
      const updateToTwo = {
        ...this.event,
        day:dayTemp,
      }
      await setDoc(updateFrom,updateToTwo);
      return docID;
    } catch (error){
      throw error;
    }

  }
}