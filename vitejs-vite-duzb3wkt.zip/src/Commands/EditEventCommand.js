// Authored by : Hayden Jones
// This Command Extends Command Interface to then sorta fully replace another event stored in the Database, when it comes to updating a doc , you can either use updateDoc for one variable a time, or setDoc, to sorta reset it, and setDoc requires less if Statements


import { setDoc,doc,getDoc } from 'firebase/firestore';
import {CommandInterface} from './CommandInterface'
import { db } from '/firebase.js';

export class EditEventCommand extends CommandInterface{
  constructor(eventObj){
    super();
    this.event= eventObj;
  }

  async execute(){
    try{
      //We first set a const of the EventID
      const docID = this.event.id;
      //Second we Get the Event from the DB
      const updateFrom = doc(db,"events",docID);
      // Setting a constant for our EventObj for later
      const updateTo = {...this.event}
      // We now have to get Data From the Doc
      const UpdateFromData = await getDoc(updateFrom)
      // we lastly Temporarly Store the day, Day is not within the FormData and so if this is not done the Day Variable is lost
      const dayTemp = UpdateFromData.data().day;

      //console.log(updateFrom)
      //console.log(updateTo)

      // This adds back in the Day variable
      const updateToTwo = {
        ...this.event,
        day:dayTemp,
      }
      // The Actual update/ SetDoc
      await setDoc(updateFrom,updateToTwo);
      return docID;
    } catch (error){
      throw error;
    }

  }
}