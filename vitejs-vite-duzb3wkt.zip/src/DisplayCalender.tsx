import { useState,useEffect } from "react";
import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore';
import {Event} from './Event/Event.js';
import {parseTime} from '../dateTime.js';
import EditEventModal from './Modals/EditEventModal.jsx';


const firebaseConfig = {
  apiKey: "AIzaSyCmxNAJ3fkDoCMS4svIWHaVajea_hoxUdE",
  authDomain: "ood-final.firebaseapp.com",
  projectId: "ood-final",
  storageBucket: "ood-final.firebasestorage.app",
  messagingSenderId: "1018216558962",
  appId: "1:1018216558962:web:00da8cc2c56b62bf246deb"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const hours = Array.from({ length: 24 }, (_, i) => {
  const hour12 = i === 0 ? 12 : i > 12 ? i - 12 : i;
  const period = i < 12 ? 'AM' : 'PM';
  return { label: `${hour12}:00 ${period}`, hour24: i };
});

export default function DisplayCalender({dayCount}) {  

  async function loadEvents() {
    try {
      const querySnapshot = await getDocs(collection(db, "events"));
      const data = querySnapshot.docs.map(doc => new Event({ id: doc.id, ...doc.data() }));
      setEvents(data);
    } catch (error) {
      console.error("Error loading events:", error);
    } finally {
      setLoading(false);
    }
}


  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  const [editModalOpen, setEditModalOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  
  function openEditModal(event: any) {
    setSelectedEvent(event);
    setEditModalOpen(true);
  }
  
  function closeEditModal() {
    setEditModalOpen(false);
  }
  
  // Calculate position and height of events
  const getEventStyle = (event) => {
    const time = String(event.time || '0000').padStart(4, '0');
    const startHour = parseInt(time.slice(0, 2));
    const startMin = parseInt(time.slice(2, 4));
    
    const durationMinutes = parseInt(event.duration) || 60;

    const HOUR_HEIGHT = 60;
    
    const startMinutes = (startHour * 60 )+ startMin;

    const height = (durationMinutes / 60) * HOUR_HEIGHT;
    const top = (startMinutes/60)*HOUR_HEIGHT+(height/2);
    console.log(event.title,'time',time,startHour,top);
    return { top, height };
  };

  const thisDaysEvents = events.filter(event => event.day === dayCount);
  const WorkColor = "#3b000"
  const PersonalColor = "#3b82f6"  
  useEffect(() => {
    async function load() {
      try {
        // Get events from Firebase
        const querySnapshot = await getDocs(collection(db, "events"));
        //Async allows for wait time 
        const data = querySnapshot.docs.map(doc => new Event({ id: doc.id, ...doc.data() }));
        setEvents(data);
      } catch (error) {
        console.error("Error loading events:", error);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);



  return(
    <div style={{ padding: '20px', fontFamily: 'system-ui, sans-serif' }}>
        <div style={{ 
          display: 'flex',
          border: '1px solid #e0e0e0',
          borderRadius: '8px',
          overflow: 'hidden',
          backgroundColor: '#fff'
        }}>
          {/* Time labels column */}
          <div style={{ 
            width: '100px',
            borderRight: '2px solid #000',
            backgroundColor: '#f9f9f9'
          }}>
            {hours.map((hour, idx) => (
              <div 
                key={idx}
                style={{
                  height: '60px',
                  borderBottom: '2px solid #000',
                  fontSize: '12px',
                  fontWeight: '600',
                  color: '#000',
                  display: 'flex',
                  alignItems: 'center'
                }}
              >
                {hour.label}
              </div>
            ))}
          </div>
    
  
          <div style={{ 
            flex: 1,
            position: 'relative',
            minHeight: '1440px' 
          }}>
            {hours.map((hour, idx) => (
              <div 
                key={idx}
                style={{
                  position: 'absolute',
                  left: 0,
                  right: 0,
                  height: '60px',
                  backgroundColor: idx % 2 === 0 ? '#fff' : '#f9f9f9'
                }}
              />
            ))}
    
            {thisDaysEvents
              .filter(event => event.time && event.duration)
              .map(event => {
                const { top, height } = getEventStyle(event);
                return (
                  <button
                  key={event.id}
                  onClick={()=> openEditModal(event)}>
                  <div 
                    key={event.id}
                    style={{
                      position: 'absolute',
                      top: `${top}px`,
                      left: '10px',
                      right: '10px',
                      height: `${height}px`,
                      backgroundColor: event.type === 'Work' ? '#FAA18F' : '#2E62FF',
                      color: '#fff',
                      overflow: 'hidden',
                      cursor: 'pointer',
                      zIndex: 10
                    }}
                  >
                    <div style={{ fontWeight: 'bold', fontSize: '14px' }}>
                      {event.title}
                    </div>
                    <div style={{ fontSize: '12px', marginTop: '4px' }}>
                      {parseTime(event.time)} • {(event.duration/60+" Hours")}
                      <p>
                      {event.description}
                      </p>
                    </div>
                  </div>
                  </button>
                );
              })}
          </div>
          {editModalOpen && selectedEvent && (
        <EditEventModal
          event={selectedEvent}
          isOpen={editModalOpen}
          onClose={closeEditModal}
          onUpdate={loadEvents} 
        />
      )}
        </div>
      </div>
    );
    
    }
    