// Authored by Brandon and Hayden
// This is the Event class Interface Sorta
// Personal and WorkEvent each extend this as part of Builder and Factory, the db is here to be used with the toFirestore Function which CreateCommand later Uses


import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { collection, addDoc, doc, getDoc, updateDoc, deleteDoc, query, getDocs } from 'firebase/firestore';

// FireStore Settings
const firebaseConfig = {
  apiKey: "AIzaSyCmxNAJ3fkDoCMS4svIWHaVajea_hoxUdE",
  authDomain: "ood-final.firebaseapp.com",
  projectId: "ood-final",
  storageBucket: "ood-final.firebasestorage.app",
  messagingSenderId: "1018216558962",
  appId: "1:1018216558962:web:00da8cc2c56b62bf246deb"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

// Class constructor and Methods
export class Event{

  //HEADER:
    //Abstract event class, all events will have these basic variables, but can be extended to include more variables

    // JS is diffrent so the constrcutor has to be restrcutred and redefined
    //

  constructor(data={}){
    this.time = data.time;
    this.duration = data.duration;
    this.title = data.title;
    this.description = data.description;
    this.location = data.location;
    this.id = data.id;
    this.type = data.type;
    this.day =data.day;
  }

 //Shows the details of the event when printed
 // For Testing Purposes
   toString(){
      return ("Title: " + title + "\nStart time: " + time + "\nDuration: " + duration +
              "\nDescription: " + description + "\nLocation: " + location + "\nDay: " + day);
  }


  toFirestore() {
    console.log(this);
    return {
      time: this.time ,
      duration: this.duration,
      title: this.title,
      description: this.description,
      location: this.location,
      type: this.type,
      day:this.day
    };
  }
}





