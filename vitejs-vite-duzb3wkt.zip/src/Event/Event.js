import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { collection, addDoc, doc, getDoc, updateDoc, deleteDoc, query, getDocs } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyCmxNAJ3fkDoCMS4svIWHaVajea_hoxUdE",
  authDomain: "ood-final.firebaseapp.com",
  projectId: "ood-final",
  storageBucket: "ood-final.firebasestorage.app",
  messagingSenderId: "1018216558962",
  appId: "1:1018216558962:web:00da8cc2c56b62bf246deb"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

export class Event{
  constructor(data={}){
    this.time = data.time;
    this.duration = data.duration;
    this.title = data.title;
    this.description = data.description;
    this.location = data.location;
    this.id = data.id;
    this.type = data.type;
    this.day =data.day;
  }


  toFirestore() {
    console.log(this);
    return {
      time: this.time ,
      duration: this.duration,
      title: this.title,
      description: this.description,
      location: this.location,
      type: this.type,
      day:this.day
    };
  }
}





