import {Event} from './Event';

export class PersonalEvent extends Event{
  constructor(time, duration, title, description, location, day) {
    super({
      time,
      duration,
      title,
      description,
      location,
      day,
      type: 'personal'
    });
  }

}
