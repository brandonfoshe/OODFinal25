// Authored by Brandon and Hayden
// Personal Event Extends Event and intializes it's type with it's paramenters

import {Event} from './Event';

export class PersonalEvent extends Event{

  //HEADER:
    //Personal event class, only needs to call the super for the constructor

  constructor(time, duration, title, description, location, day) {
    super({
      time,
      duration,
      title,
      description,
      location,
      day,
      type: 'personal'
    });
  }

}
