import {Event} from './Event';

export class WorkEvent extends Event{
  constructor(time, duration, title, description, location, day) {
    super({
      time,
      duration,
      title,
      description,
      location,
      day,
      type: 'Work'
    });
  }
}

