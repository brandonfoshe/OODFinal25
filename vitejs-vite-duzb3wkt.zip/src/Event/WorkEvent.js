// Authored by Brandon and Hayden
// Work Event Extends Event and intializes it's type with it's paramenters

import {Event} from './Event';

export class WorkEvent extends Event{
  constructor(time, duration, title, description, location, day) {
    super({
      time,
      duration,
      title,
      description,
      location,
      day,
      type: 'Work'
    });
  }
}

