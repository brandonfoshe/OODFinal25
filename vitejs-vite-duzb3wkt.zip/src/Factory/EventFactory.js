// Authored by Brandon and Hayden
// Event Factory calls a Builder to then Create a WorkEvent or PersonalEvent

import {EventBuilder} from "../Builder/EventBuilder"

export class EventFactory{
  createWorkEvent(builder){
    const event = (builder.buildWorkEvent());
    return event;
}
  
createPersonalEvent(builder){
  const event =(builder.buildPersonalEvent());
  return event;
}
}