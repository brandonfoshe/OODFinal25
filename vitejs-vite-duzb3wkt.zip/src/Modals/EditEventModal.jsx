// Authored by : Hayden Jones
// The Modal is one way to have the Form appear on screen i found worth it to attempt
// This has an Command Invoker and an instance of Delete Command and EditEventCommand


import React, { useEffect, useState } from 'react';
import Modal from 'react-modal';
import {db} from '../../firebase.js'
import { CommandInvoker } from '../Commands/CommandInvoker';
import { EditEventCommand } from '../Commands/EditEventCommand'
import { DeleteCommand } from '../Commands/DeleteCommand'

// css Style was with the Example copied over from https://www.npmjs.com/package/react-modal
// this i believe is the transparency aspect 
const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
  },
};
// Actual Modal Time
// Passes 4 parameters for the Event being Edited, wether open,What to do on close, and what to do when an input is changed
export default function EditEventModal({ event, isOpen, onClose, onUpdate }) {
  // Form Data is populated with the Event Data that exists for Event to later be changed if the Edit Button is pressed
  const [formData, setFormData] = useState({
    id: event.id || '',
    title: event.title || '',
    description: event.description || '',
    location: event.location || '',
    time: event.time || '',
    duration: event.duration || '',
    type: event.type || ''

  });

  // Handles Change of Form inputs
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  // Handles Submit of Edit, intializes the Invoker and command with the Data from the form to edit the established Event.id
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      console.log(formData);
      const editCommand = new EditEventCommand(formData);
      const Invoker = new CommandInvoker();
      Invoker.setCommand(editCommand);

      await Invoker.executeCommand();

      // Console Log left over from Bug Finding
      //console.log("Invoker executed")

      onUpdate();

    } catch (error) {
      console.error("Error executing edit command:", error);
    }
    
    onClose();
  }
  // For the Delete Button, CommandInvoker and DeleteCommand Here
  const onDelete = async (e) => {
    try{

      const delete2 = new DeleteCommand(formData);
      const Invoker = new CommandInvoker();
      Invoker.setCommand(delete2);

      //Left over Log from Bug Finding
      //console.log("Deleted")

      await Invoker.executeCommand();

      // Resets events shown on page 
      onUpdate();
      onClose();
    } catch(error){
      throw error;
    }
  }
 // For the Open of the Modal the setting of the Data has to be done again to reintialize incase the Event being Edited changed, like a click away from event A and then click out, then a click on Event B

  useEffect(() => {
    if (isOpen && event) {
      setFormData({
        id: event.id || '',
        title: event.title || '',
        description: event.description || '',
        location: event.location || '',
        time: event.time || '',
        duration: event.duration || '',
        type: event.type || ''
      });
    }
  }, [event, isOpen]);

  // Actual Visual Things
  return (
    <div>
      <Modal
        isOpen={isOpen} 
        onRequestClose={onClose}
        style={customStyles}
        contentLabel="Edit Event Modal"
      >
        <h2>Edit Event</h2>
        <form onSubmit={handleSubmit}>
          
          <div>
            <label>Event Type:</label>
            <select
              name="type"
              value={formData.Type}
              onChange={handleChange}
              required
            >
              <option value="personal">Personal</option>
              <option value="Work">Work</option>
            </select>
          </div>
          
          <div>
            <label>Title:</label>
            <input
              placeholder="Type Title Here"
              name="title"
              value={formData.title}
              onChange={handleChange}
              required
            />
          </div>
          
          <div>
            <label>Time:</label>
            <input
              placeholder="Time from 0000-2359"
              type='number'
              name="time"
              value={formData.time}
              onChange={handleChange}
              required
            />
          </div>
          
          <div>
            <label>Duration (Minutes):</label>
            <input
              placeholder="Duration Minutes (e.g., 60)"
              type='number'
              name="duration"
              value={formData.duration}
              onChange={handleChange}
              required
            />
          </div>
          
          <div>
            <label>Location:</label>
            <input
              placeholder="Type Location Here"
              name="location"
              value={formData.location}
              onChange={handleChange}
              required
            />
          </div>
          
          <div>
            <label>Description:</label>
            <input
              placeholder="Type Description Here"
              name="description"
              value={formData.description}
              onChange={handleChange}
              required
            />
          </div>

          <button type="submit">
            Update Event
            </button>
          
          <button type="button" onClick={onClose} style={{ marginLeft: '10px' }}>
            Cancel
          </button>
          <button type="button" onClick={onDelete} style={{ marginLeft: '10px' }}>
            Delete
          </button>
        </form>
      </Modal>
    </div>
  );
}