import React, { useEffect, useState } from 'react';
import Modal from 'react-modal';
import { EventFactory } from '../Factory/EventFactory.js'; 
import {db} from '../../firebase.js'
import { CommandInvoker } from '../Commands/CommandInvoker';
import { EditEventCommand } from '../Commands/EditEventCommand'
import { DeleteCommand } from '../Commands/DeleteCommand'

const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
  },
};

export default function EditEventModal({ event, isOpen, onClose, onUpdate }) {
  
  const [formData, setFormData] = useState({
    id: event.id || '',
    title: event.title || '',
    description: event.description || '',
    location: event.location || '',
    time: event.time || '',
    duration: event.duration || '',
    type: event.type || ''

  });

  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      console.log(formData);
      const editCommand = new EditEventCommand(formData);
      const Invoker = new CommandInvoker();
      Invoker.setCommand(editCommand);

      await Invoker.executeCommand();
      console.log("Invoker executed")
      onUpdate();

    } catch (error) {
      console.error("Error executing edit command:", error);
    }
    
    onClose();
  }

  const onDelete = async (e) => {
    try{

      const delete2 = new DeleteCommand(formData);
      const Invoker = new CommandInvoker();
      Invoker.setCommand(delete2);
      console.log("Deleted")
      await Invoker.executeCommand();

      onUpdate();
      onClose();
    } catch(error){
      throw error;
    }
  }
 
  useEffect(() => {
    if (isOpen && event) {
      setFormData({
        id: event.id || '',
        title: event.title || '',
        description: event.description || '',
        location: event.location || '',
        time: event.time || '',
        duration: event.duration || '',
        type: event.type || ''
      });
    }
  }, [event, isOpen]);

  return (
    <div>
      <Modal
        isOpen={isOpen} 
        onRequestClose={onClose}
        style={customStyles}
        contentLabel="Edit Event Modal"
      >
        <h2>Edit Event</h2>
        <form onSubmit={handleSubmit}>
          
          <div>
            <label>Event Type:</label>
            <select
              name="type"
              value={formData.Type}
              onChange={handleChange}
              required
            >
              <option value="personal">Personal</option>
              <option value="Work">Work</option>
            </select>
          </div>
          
          <div>
            <label>Title:</label>
            <input
              placeholder="Type Title Here"
              name="title"
              value={formData.title}
              onChange={handleChange}
              required
            />
          </div>
          
          <div>
            <label>Time:</label>
            <input
              placeholder="Time from 0000-2359"
              type='number'
              name="time"
              value={formData.time}
              onChange={handleChange}
              required
            />
          </div>
          
          <div>
            <label>Duration (Minutes):</label>
            <input
              placeholder="Duration Minutes (e.g., 60)"
              type='number'
              name="duration"
              value={formData.duration}
              onChange={handleChange}
              required
            />
          </div>
          
          <div>
            <label>Location:</label>
            <input
              placeholder="Type Location Here"
              name="location"
              value={formData.location}
              onChange={handleChange}
              required
            />
          </div>
          
          <div>
            <label>Description:</label>
            <input
              placeholder="Type Description Here"
              name="description"
              value={formData.description}
              onChange={handleChange}
              required
            />
          </div>

          <button type="submit">
            Update Event
            </button>
          
          <button type="button" onClick={onClose} style={{ marginLeft: '10px' }}>
            Cancel
          </button>
          <button type="button" onClick={onDelete} style={{ marginLeft: '10px' }}>
            Delete
          </button>
        </form>
      </Modal>
    </div>
  );
}