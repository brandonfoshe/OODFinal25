// Authored by : Hayden Jones
// The Modal is one way to have the Form appear on screen i found worth it to attempt
// This has an Event Factory, Command Invoker and an instance of Delete Command and EditEventCommand



//https://www.npmjs.com/package/react-modal
// This was used as a template ro create the Pop-Up Event Creation


import React from 'react';
import ReactDOM from 'react-dom';
import Modal from 'react-modal';
import { EventFactory } from '../Factory/EventFactory';
import {useState} from 'react'
import { collection } from 'firebase/firestore';
import {addDoc} from 'firebase/firestore'; 
import {db} from '../../firebase.js'
import {CreateEventCommand} from '../Commands/CreateEventCommand'
import { CommandInterface } from '../Commands/CommandInterface';
import { CommandInvoker } from '../Commands/CommandInvoker';
import {EventBuilder} from '../Builder/EventBuilder';

const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
  },
};

  
// Make sure to bind modal to your appElement (https://reactcommunity.org/react-modal/accessibility/)
//Modal.setAppElement('#yourAppElement');
// this is done in App later


export default function EventModal({modalIsOpen,closeModal,onEventCreated,dayCount}) {
  // LeftOver from the Template
  let subtitle;

  // Event Factory is Intialized here
  const eventFactory = new EventFactory();
  // FormData intialization for the Inputs in Return
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    location: '',
    time: '',
    duration: '',
    eventType: 'personal',
    day: dayCount
  });

  // This sets the "formData to the accurate inputs"
  const handleChange = (e) => {
    
    const {name, value, type} = e.target;

    let newValue = value; 
    // Ensures Numbers are Numbers 
    if(type === 'number'){
      
      if(value === ''){
        newValue = '';
      } else {
        newValue = parseFloat(value);
        
        if (isNaN(newValue)){
          return;
        }
      }
    }
    //Sets the Form on changes
    setFormData(prev=>({
      ...prev,
      [name]: newValue 
    }));
};
  // 
  const handleSubmit = async (e) => {
    e.preventDefault();
    const eventBuilder = new EventBuilder();
    let newEvent;
    if(formData.eventType === 'Work'){
      newEvent = eventFactory.createWorkEvent(
        eventBuilder
          .setTime(formData.time)
          .setDuration(formData.duration)
          .setTitle(formData.title)
          .setDescription(formData.description)
          .setLocation(formData.location)
          .setDay(dayCount)
      );
    }
     else{
      newEvent = eventFactory.createPersonalEvent(
        eventBuilder
          .setTime(formData.time)
          .setDuration(formData.duration)
          .setTitle(formData.title)
          .setDescription(formData.description)
          .setLocation(formData.location)
          .setDay(dayCount)
      );
    }
    // As part of the firebase Async Functions are needed to allow time for communicaton,
    // try and catch methods must be implemented for async methods
    // here we intialize our Invoker, and Command, I had Issues Intializing Invoker In larger CLasses such as the Pages themself, As each Function is Part of a larger Display It was simplest to have invoker made and used within the Try part of this constant
    try{
      console.log(newEvent)
      const createCommand = new CreateEventCommand(newEvent);
      const Invoker = new CommandInvoker();
      Invoker.setCommand(createCommand);
      const newEventID = await Invoker.executeCommand();
    } catch (error){
      throw error;
    }
    // reset for a new event
    setFormData({
      title:'',
      description:'',
      location:'',
      time:'',
      duration:'',
      eventType:'Personal'
    });
    // close the pop-up
    // Currently im having issues getting events to load after creation, now a window refresh is coded to force it
    closeModal();
    window.location.reload();
  }

// Everything Display wise is here alot of this is copy-paste from the example
// //https://www.npmjs.com/package/react-modal
// This was used as a template ro create the Pop-Up Event Creation
// edits were done to the CSS at time and usage of our functions
return (
  <div>
    <Modal
      isOpen={modalIsOpen}
      onRequestClose={closeModal}
      style={customStyles}
      contentLabel="Example Modal"
    >
      <form onSubmit={handleSubmit}>
        <div>

          <label>
            Event Type:
            </label>
            <select
            name="eventType"
            value={formData.eventType}
            onChange={handleChange}
            required
            >
              <option value="Personal">
                Personal
                </option>
                <option value="Work">
                Work
                </option>
                </select>
        </div>

  
        <div>
          <label>
             Title:
             </label>
          <input
            placeholder="Type Title Here"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
            />
          </div>
          <div>
          <label>
             Time:
             </label>
          <input
          placeholder="Time from 0001-2399"
            type='number'
            name="time"
            value={formData.time}
            onChange={handleChange}
            required
            />
          </div>
          <div>
          <label>
             Duration:
             </label>
          <input
          placeholder="Duration Minutes(0001-2399)"
            type='number'
            name="duration"
            value={formData.duration}
            onChange={handleChange}
            required
            />
          </div>
          <div>
          <label>
             Location:
             </label>
          <input
          placeholder="Type Location Here"
            name="location"
            value={formData.location}
            onChange={handleChange}
            required
            />
          </div>
          <div>
          <label>
             Description:
             </label>
          <input
          placeholder="Type Description Here"
            name="description"
            value={formData.description}
            onChange={handleChange}
            required
            />
          </div>

      <button type="submit">
        Create!
        </button>
        </form>
    </Modal>
  </div>
);
}