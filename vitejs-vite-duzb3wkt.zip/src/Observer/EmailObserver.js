// THis is the publisher of the Observer, running the Notify Event when the Time of the Event is at hand


export default class EmailObserver{
  constructor(){
    this.subscribers=[];
  }

  addSubscriber(subscriber){
    this.subscribers.push(subscriber);
  }

  removeSubscriber(subscriber){
    const index = this.subscribers.indexOf(subscriber);
    if (index > -1){
      this.subscribers.splice(index,1);
    }
  }

  async update(event){
    for (const subscriber of this.subscribers){
      await subscriber.notify(event);
    }
  }
}
