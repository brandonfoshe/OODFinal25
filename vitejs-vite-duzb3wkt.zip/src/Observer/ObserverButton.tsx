// This is the Simulated Time efeect for the observer which is prompted to send notifications

import EmailObserver from './EmailObserver'
import { db } from '../../firebase.js'
import {useState,useEffect, useRef} from 'react'
import {collection, getDocs,doc} from 'firebase/firestore'
import {Event} from "../Event/Event.js"
import {EmailSubscriber} from "./Subscriber.js"


export default function ObserverButton(){

  const observerLast = useRef(new EmailObserver());
 const observer = observerLast.current;
 const [events, setEvents] = useState([]);
 const [curHour,setHour] = useState(0);
 const [email,setEmail] = useState("");


// This use Effect gets the events via Database
  useEffect(() =>{
    async function load() {
      try {
        //FireBase Connection, getDocs
        const querySnapshot = await getDocs(collection(db, "events"));
      
        // Get Event+Data/Details
        const data = querySnapshot.docs.map(doc => {
          const eventData = doc.data();
          // Return as Event Objects
          return new Event({
            id: doc.id,
            name: eventData.name,
            time: eventData.time,
            day: eventData.day,
            description: eventData.description,
            duration: eventData.duration,
            notified: false
          });
        });
        
        console.log('Loaded events:', data);
        setEvents(data);
      } catch (error) {
        console.error("Error loading events:", error);
      }
    }
    load();
    }, []);

// This Effect Begins the Simulated Time for the Week
  useEffect(()=>{
    const int = setInterval(()=>{
      setHour(prev => prev+1);
    },1000)
    return()=> clearInterval(int);
  },[])
// This Effect Checks against simulated time and Event times
useEffect(()=>{
  events.forEach(event =>{
    const timeStr = event.time.toString(); 
    let hour = parseInt(timeStr.slice(0, 2));
    let curday = event.day;
    if (curday !== 1){
      hour = hour +((curday-1)*24)
    }
    if (hour === curHour && !event.notified){
      console.log("oBSERVER subscribers"+observer.subscribers)
      observer.update(event)

      event.notified= true;
    }
  })
}, [curHour,events,observer]);

const handleSubmit = async (e) => {
  e.preventDefault();
  const subscriber = new EmailSubscriber(email);
  observer.addSubscriber(subscriber);
  console.log("Subcriber added to list")
}


  return (
    <div>
      <h1>
      Simulated Hour:{curHour}:00
      </h1>
      <form onSubmit={handleSubmit}>
       <label>
        Notification Email:
       <input type='email'
       value={email}
        onChange={(e)=> setEmail(e.target.value)}
        placeholder="Type Email Here"
       />
      <button type="submit">
        Submit
        </button>
      </label>
      </form>
    </div>
  )
  }