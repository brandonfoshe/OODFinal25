// THis is a subscriber, holds an email and the methods to Notify via email, using EmailJS 

import emailjs from "@emailjs/browser";

emailjs.init("WaJkvIf1F3B-p37G7");
// Interface Like Class
export class Subscriber{
  async notify(event){
  }
}
// Email SUbscriber Extends Subscriber , implementing Notify and the Email Variable
export class EmailSubscriber extends Subscriber{
  constructor(email){
    super();
    this.email=email ;
  }
  // Async needed for waiting and also , this shoulda been sending an email with the title of the Event, i can't figure out why it doesnt send any details
  async notify(event){
    try{
      console.log("entered Notify")
      const templateParams  ={
        to_email:this.email,
        title:event.title,
        event_desc:event.description,
        event_time:event.time,
        event_dur:event.duration
      };
      console.log
      const resolve = await emailjs.send(
        "service_zb97yyr",
        "template_kpxgs7g",
        templateParams,
        "WaJkvIf1F3B-p37G7"
      );
      // Left over log from Bug-Fixing
      //console.log("email sent")
  } catch (error){
    throw error;
  }
}
}

