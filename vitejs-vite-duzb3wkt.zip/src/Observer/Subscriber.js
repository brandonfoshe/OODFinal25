import emailjs from "@emailjs/browser";

emailjs.init("WaJkvIf1F3B-p37G7");

export class Subscriber{
  async notify(event){
  }
}

export class EmailSubscriber extends Subscriber{
  constructor(email){
    super();
    this.email=email ;
  }

  async notify(event){
    try{
      console.log("entered Notify")
      const templateParams  ={
        to_email:this.email,
        title:event.title,
        event_desc:event.description,
        event_time:event.time,
        event_dur:event.duration
      };
      console.log
      const resolve = await emailjs.send(
        "service_zb97yyr",
        "template_kpxgs7g",
        templateParams,
        "WaJkvIf1F3B-p37G7"
      );
      console.log("email sent")
  } catch (error){
    throw error;
  }
}
}

