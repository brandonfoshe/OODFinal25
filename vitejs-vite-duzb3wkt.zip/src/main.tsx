import { createRoot } from 'react-dom/client'
import Sunday from './pages/Sunday.tsx'
import Monday from './pages/Monday.tsx'
import Tuesday from './pages/Tuesday.tsx'
import Wednesday from './pages/Wednesday.tsx'
import Thursday from './pages/Thursday.tsx'
import Friday from './pages/Friday.tsx'
import Saturday from './pages/Saturday.tsx'
import WeekView from './pages/WeekView.tsx'
import MyNavbar from "./myNavbar"
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import Modal from 'react-modal';


Modal.setAppElement('#root');

function AppRouter() {
  return (
    <>
      <MyNavbar />
      <Routes>
        <Route path="/" element={<Sunday />} /> 
        <Route path="/Monday" element={<Monday />} />
        <Route path="/Tuesday" element={<Tuesday />} />
        <Route path="/Wednesday" element={<Wednesday />} /> 
        <Route path="/Thursday" element={<Thursday />} />
        <Route path="/Friday" element={<Friday />} />
        <Route path="/Saturday" element={<Saturday/>}/>
        <Route path="/WeekView" element={<WeekView/>}/>
      </Routes>
    </>
  );
}

const root = createRoot(document.getElementById('root')!)

root.render(
  <BrowserRouter>
    <AppRouter /> 
  </BrowserRouter>
)