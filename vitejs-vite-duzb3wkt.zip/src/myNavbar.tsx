import {  Navbar,   NavbarBrand,   NavbarContent,   NavbarItem,   NavbarMenuToggle,  NavbarMenu,  NavbarMenuItem} from "@heroui/navbar";
import { useState } from "react";
import { Button } from "@heroui/react";
import { useNavigate } from 'react-router-dom';
// import { Calendar } from 'lucide-react';

export default function MyNavbar(){
  const [isOpen,setisOpen] = useState(false);
  const navigate = useNavigate();
  return (
    <Navbar onMenuOpenChange={setisOpen}>
  <NavbarContent 
  style={{ display: 'flex', flexDirection: 'row', gap:'32px', alignItems: 'center' }}>

    <NavbarBrand>
       <Button
             onClick={() => navigate('/')}
       style={{
         borderRadius:'22px',
         fontSize:'16px',
         color: 'white',
         backgroundColor: '#000000'
       }}>
      <p>Sunday</p>
      </Button>
    </NavbarBrand>

    <NavbarItem>
    <Button
       onClick={() => navigate('/Monday')}
       style={{
         borderRadius:'22px',
         fontSize:'16px',
         color: 'white',
         backgroundColor: '#000000'
       }}>
      <p>Monday</p>
      </Button>
    </NavbarItem>
    <NavbarItem>
    <Button
       onClick={() => navigate('/Tuesday')}
       style={{
         borderRadius:'22px',
         fontSize:'16px',
         color: 'white',
         backgroundColor: '#000000'
       }}>
      <p>Tuesday</p>
      </Button>
    </NavbarItem>
    <NavbarItem>
    <Button
       onClick={() => navigate('/Wednesday')}
       style={{
         borderRadius:'22px',
         fontSize:'16px',
         color: 'white',
         backgroundColor: '#000000'
       }}>
      <p>Wednesday</p>
      </Button>
    </NavbarItem>

    <NavbarItem>
    <Button
       onClick={() => navigate('/Thursday')}
       style={{
         textAlign:"right",
         borderRadius:'22px',
         fontSize:'16px',
         color: 'white',
         backgroundColor: '#000000'
       }}>
      <p>Thursday</p>
      </Button>
    </NavbarItem>
    <NavbarItem>
    <Button
       onClick={() => navigate('/Friday')}
       style={{
         textAlign:"right",
         borderRadius:'22px',
         fontSize:'16px',
         color: 'white',
         backgroundColor: '#000000'
       }}>
      <p>Friday</p>
      </Button>
    </NavbarItem>
    <NavbarItem>
    <Button
       onClick={() => navigate('/Saturday')}
       style={{
         textAlign:"right",
         borderRadius:'22px',
         fontSize:'16px',
         color: 'white',
         backgroundColor: '#000000'
       }}>
      <p>Saturday</p>
      </Button>
    </NavbarItem>
    <NavbarItem>
    <Button
       onClick={() => navigate('/WeekView')}
       style={{
         textAlign:"right",
         borderRadius:'22px',
         fontSize:'16px',
         color: 'white',
         backgroundColor: '#000000'
       }}>
      <p>Week View</p>
      </Button>
    </NavbarItem>
  </NavbarContent>
</Navbar>

  )
}