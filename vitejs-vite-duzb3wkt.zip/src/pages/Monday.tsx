
import DisplayCalender from '../DisplayCalender'
import EventModal from '../Modals/EventModal'
import {useState} from 'react'

export default function Monday(){

  const [modalIsOpen,setIsOpen] = useState(false);

  const openModal =() =>{
    setIsOpen(true);
  };

  const closeModal =() =>{
    setIsOpen(false);
  };

  return (
    <div>

            <div style={{
              textAlign: 'center',
            }}>
                  <p>
                  Monday Calender:
                  </p>
                  <button 
                  onClick={openModal}
                  closeModal={closeModal}
                  >
                    Create New Event
                    </button>
                  </div>
                  <div>
                      <DisplayCalender
                       dayCount={2}>
                        </DisplayCalender>
                    </div>
                    <EventModal modalIsOpen={modalIsOpen} closeModal={closeModal}  dayCount={2}/>
        </div>

  )
}