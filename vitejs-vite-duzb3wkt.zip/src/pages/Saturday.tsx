import MyNavbar from '../myNavbar'
import DisplayCalender from '../DisplayCalender'
import EventModal from '../Modals/EventModal'
import {useState} from 'react'
// import EventForm from './EventForm'
//import {Routes,Route} from 'react-router-dom'

export default function Saturday(){

  const [modalIsOpen,setIsOpen] = useState(false);

  const openModal =() =>{
    setIsOpen(true);
  };

  const closeModal =() =>{
    setIsOpen(false);
  };

  return (
    <div>

            <div style={{
              textAlign: 'center',
            }}>
                  <p>
                  Saturday Calender:
                  </p>
                  <button 
                  onClick={openModal}
                  closeModal={closeModal}

                  >
                    Create New Event
                    </button>
                  </div>
                  <div>
                      <DisplayCalender
                      dayCount={7}
                      >
                        </DisplayCalender>
                    </div>
                    <EventModal modalIsOpen={modalIsOpen} closeModal={closeModal} dayCount={7}/>

                    <MyNavbar>
        </MyNavbar>
        </div>

  )
}