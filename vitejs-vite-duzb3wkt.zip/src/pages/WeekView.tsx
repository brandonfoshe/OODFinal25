import MyNavbar from '../myNavbar'
import DisplayCalender from '../DisplayCalender'
import EventModal from '../Modals/EventModal'
import DisplayWeek from "../DisplayWeek"
// import EventForm from './EventForm'
//import {Routes,Route} from 'react-router-dom'

export default function WeekView(){
  return (
    <div>

            <div style={{
              textAlign: 'center',
            }}>
                  <p>
                  Week Long Calender:
                  </p>

                  </div>
                  <div>
                    <DisplayWeek>
                      </DisplayWeek>
                    </div>
                  
        </div>

  )
}